
"use strict";

let Face = require('./Face.js');
let f_id = require('./f_id.js');
let PeopleFace = require('./PeopleFace.js');
let Luminance = require('./Luminance.js');
let Point2D = require('./Point2D.js');
let MotorStateList = require('./MotorStateList.js');
let Tracker = require('./Tracker.js');
let Viseme = require('./Viseme.js');
let SourceInfoWithCovariance = require('./SourceInfoWithCovariance.js');
let Trackers = require('./Trackers.js');
let BlinkCycle = require('./BlinkCycle.js');
let MakeFaceExpr = require('./MakeFaceExpr.js');
let Vision = require('./Vision.js');
let FSValues = require('./FSValues.js');
let SalientPoint = require('./SalientPoint.js');
let Assign = require('./Assign.js');
let ForgetAll = require('./ForgetAll.js');
let faces_ids = require('./faces_ids.js');
let Objects = require('./Objects.js');
let Motions = require('./Motions.js');
let ManyEarsTrackedAudioSource = require('./ManyEarsTrackedAudioSource.js');
let PiVisionFace = require('./PiVisionFace.js');
let FacialActionUnit = require('./FacialActionUnit.js');
let facebox = require('./facebox.js');
let Target = require('./Target.js');
let Body = require('./Body.js');
let MotionSignal = require('./MotionSignal.js');
let ChatResponse = require('./ChatResponse.js');
let Doa = require('./Doa.js');
let MotorState = require('./MotorState.js');
let SourceInfo = require('./SourceInfo.js');
let faces = require('./faces.js');
let TTS = require('./TTS.js');
let SetGestureClip = require('./SetGestureClip.js');
let SoulTalkChat = require('./SoulTalkChat.js');
let PlayAnimation = require('./PlayAnimation.js');
let Visemes = require('./Visemes.js');
let Strokes = require('./Strokes.js');
let SetExpression = require('./SetExpression.js');
let MotorCommand = require('./MotorCommand.js');
let Status = require('./Status.js');
let Gesture = require('./Gesture.js');
let FaceEvent = require('./FaceEvent.js');
let Gestures = require('./Gestures.js');
let Object = require('./Object.js');
let SomaState = require('./SomaState.js');
let ChatMessage = require('./ChatMessage.js');
let PointHead = require('./PointHead.js');
let Faces = require('./Faces.js');
let pau = require('./pau.js');
let Forget = require('./Forget.js');
let Stroke = require('./Stroke.js');
let Hand = require('./Hand.js');
let People = require('./People.js');
let audiodata = require('./audiodata.js');
let Point2DArray = require('./Point2DArray.js');
let SaccadeCycle = require('./SaccadeCycle.js');
let PiVisionFaces = require('./PiVisionFaces.js');
let targets = require('./targets.js');
let PeopleFaces = require('./PeopleFaces.js');
let AudioStream = require('./AudioStream.js');
let Event = require('./Event.js');
let SomaStates = require('./SomaStates.js');
let CurrentFrame = require('./CurrentFrame.js');
let FSShapekey = require('./FSShapekey.js');
let FSShapekeys = require('./FSShapekeys.js');
let ChatResponses = require('./ChatResponses.js');
let HeadFun = require('./HeadFun.js');
let Feature = require('./Feature.js');
let EventMessage = require('./EventMessage.js');
let Person = require('./Person.js');
let Features = require('./Features.js');
let SetAnimation = require('./SetAnimation.js');
let PiFace = require('./PiFace.js');
let VADMessage = require('./VADMessage.js');
let GetAPIVersion = require('./GetAPIVersion.js');
let TTSItem = require('./TTSItem.js');
let TargetPosture = require('./TargetPosture.js');
let Motion = require('./Motion.js');

module.exports = {
  Face: Face,
  f_id: f_id,
  PeopleFace: PeopleFace,
  Luminance: Luminance,
  Point2D: Point2D,
  MotorStateList: MotorStateList,
  Tracker: Tracker,
  Viseme: Viseme,
  SourceInfoWithCovariance: SourceInfoWithCovariance,
  Trackers: Trackers,
  BlinkCycle: BlinkCycle,
  MakeFaceExpr: MakeFaceExpr,
  Vision: Vision,
  FSValues: FSValues,
  SalientPoint: SalientPoint,
  Assign: Assign,
  ForgetAll: ForgetAll,
  faces_ids: faces_ids,
  Objects: Objects,
  Motions: Motions,
  ManyEarsTrackedAudioSource: ManyEarsTrackedAudioSource,
  PiVisionFace: PiVisionFace,
  FacialActionUnit: FacialActionUnit,
  facebox: facebox,
  Target: Target,
  Body: Body,
  MotionSignal: MotionSignal,
  ChatResponse: ChatResponse,
  Doa: Doa,
  MotorState: MotorState,
  SourceInfo: SourceInfo,
  faces: faces,
  TTS: TTS,
  SetGestureClip: SetGestureClip,
  SoulTalkChat: SoulTalkChat,
  PlayAnimation: PlayAnimation,
  Visemes: Visemes,
  Strokes: Strokes,
  SetExpression: SetExpression,
  MotorCommand: MotorCommand,
  Status: Status,
  Gesture: Gesture,
  FaceEvent: FaceEvent,
  Gestures: Gestures,
  Object: Object,
  SomaState: SomaState,
  ChatMessage: ChatMessage,
  PointHead: PointHead,
  Faces: Faces,
  pau: pau,
  Forget: Forget,
  Stroke: Stroke,
  Hand: Hand,
  People: People,
  audiodata: audiodata,
  Point2DArray: Point2DArray,
  SaccadeCycle: SaccadeCycle,
  PiVisionFaces: PiVisionFaces,
  targets: targets,
  PeopleFaces: PeopleFaces,
  AudioStream: AudioStream,
  Event: Event,
  SomaStates: SomaStates,
  CurrentFrame: CurrentFrame,
  FSShapekey: FSShapekey,
  FSShapekeys: FSShapekeys,
  ChatResponses: ChatResponses,
  HeadFun: HeadFun,
  Feature: Feature,
  EventMessage: EventMessage,
  Person: Person,
  Features: Features,
  SetAnimation: SetAnimation,
  PiFace: PiFace,
  VADMessage: VADMessage,
  GetAPIVersion: GetAPIVersion,
  TTSItem: TTSItem,
  TargetPosture: TargetPosture,
  Motion: Motion,
};
