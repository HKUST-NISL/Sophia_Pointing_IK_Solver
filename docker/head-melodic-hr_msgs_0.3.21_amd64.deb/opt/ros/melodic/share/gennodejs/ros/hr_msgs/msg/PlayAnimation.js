// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PlayAnimation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.animation = null;
      this.fps = null;
    }
    else {
      if (initObj.hasOwnProperty('animation')) {
        this.animation = initObj.animation
      }
      else {
        this.animation = '';
      }
      if (initObj.hasOwnProperty('fps')) {
        this.fps = initObj.fps
      }
      else {
        this.fps = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlayAnimation
    // Serialize message field [animation]
    bufferOffset = _serializer.string(obj.animation, buffer, bufferOffset);
    // Serialize message field [fps]
    bufferOffset = _serializer.int64(obj.fps, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlayAnimation
    let len;
    let data = new PlayAnimation(null);
    // Deserialize message field [animation]
    data.animation = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [fps]
    data.fps = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.animation.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/PlayAnimation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c00c0ae8e42a687c424ac0f67577887a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string animation
    int64 fps
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlayAnimation(null);
    if (msg.animation !== undefined) {
      resolved.animation = msg.animation;
    }
    else {
      resolved.animation = ''
    }

    if (msg.fps !== undefined) {
      resolved.fps = msg.fps;
    }
    else {
      resolved.fps = 0
    }

    return resolved;
    }
};

module.exports = PlayAnimation;
