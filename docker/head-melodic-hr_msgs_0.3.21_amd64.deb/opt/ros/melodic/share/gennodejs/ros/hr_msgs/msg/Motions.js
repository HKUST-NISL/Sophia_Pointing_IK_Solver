// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Motion = require('./Motion.js');

//-----------------------------------------------------------

class Motions {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.motions = null;
    }
    else {
      if (initObj.hasOwnProperty('motions')) {
        this.motions = initObj.motions
      }
      else {
        this.motions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Motions
    // Serialize message field [motions]
    // Serialize the length for message field [motions]
    bufferOffset = _serializer.uint32(obj.motions.length, buffer, bufferOffset);
    obj.motions.forEach((val) => {
      bufferOffset = Motion.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Motions
    let len;
    let data = new Motions(null);
    // Deserialize message field [motions]
    // Deserialize array length for message field [motions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.motions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.motions[i] = Motion.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.motions.forEach((val) => {
      length += Motion.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Motions';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '424458963ba98fdb12e7be46647bd970';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Motion[] motions # array of motions
    
    ================================================================================
    MSG: hr_msgs/Motion
    string name         # name of motion
    bool   active       # is motion active
    int32  priority     # priority of motion
    MotionSignal[] motionSignals # state of the motion signals
    
    ================================================================================
    MSG: hr_msgs/MotionSignal
    string  name       # signal name
    bool    isActive   # indicates if node is currently active
    float64 timePassed # time since the 'isActive' label has changed
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Motions(null);
    if (msg.motions !== undefined) {
      resolved.motions = new Array(msg.motions.length);
      for (let i = 0; i < resolved.motions.length; ++i) {
        resolved.motions[i] = Motion.Resolve(msg.motions[i]);
      }
    }
    else {
      resolved.motions = []
    }

    return resolved;
    }
};

module.exports = Motions;
