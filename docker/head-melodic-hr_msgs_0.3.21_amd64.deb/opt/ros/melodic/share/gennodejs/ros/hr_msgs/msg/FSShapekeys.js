// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let FSShapekey = require('./FSShapekey.js');

//-----------------------------------------------------------

class FSShapekeys {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.shapekey = null;
    }
    else {
      if (initObj.hasOwnProperty('shapekey')) {
        this.shapekey = initObj.shapekey
      }
      else {
        this.shapekey = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FSShapekeys
    // Serialize message field [shapekey]
    // Serialize the length for message field [shapekey]
    bufferOffset = _serializer.uint32(obj.shapekey.length, buffer, bufferOffset);
    obj.shapekey.forEach((val) => {
      bufferOffset = FSShapekey.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FSShapekeys
    let len;
    let data = new FSShapekeys(null);
    // Deserialize message field [shapekey]
    // Deserialize array length for message field [shapekey]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.shapekey = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.shapekey[i] = FSShapekey.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.shapekey.forEach((val) => {
      length += FSShapekey.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/FSShapekeys';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '24c40a14c4abc24838af1fa559edadbb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    FSShapekey[] shapekey
    
    ================================================================================
    MSG: hr_msgs/FSShapekey
    string name
    float32 value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FSShapekeys(null);
    if (msg.shapekey !== undefined) {
      resolved.shapekey = new Array(msg.shapekey.length);
      for (let i = 0; i < resolved.shapekey.length; ++i) {
        resolved.shapekey[i] = FSShapekey.Resolve(msg.shapekey[i]);
      }
    }
    else {
      resolved.shapekey = []
    }

    return resolved;
    }
};

module.exports = FSShapekeys;
