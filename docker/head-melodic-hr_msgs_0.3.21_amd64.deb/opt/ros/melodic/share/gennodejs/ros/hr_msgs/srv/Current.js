// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class CurrentRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CurrentRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CurrentRequest
    let len;
    let data = new CurrentRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/CurrentRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CurrentRequest(null);
    return resolved;
    }
};

class CurrentResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.performance = null;
      this.current_time = null;
      this.running = null;
      this.paused = null;
    }
    else {
      if (initObj.hasOwnProperty('performance')) {
        this.performance = initObj.performance
      }
      else {
        this.performance = '';
      }
      if (initObj.hasOwnProperty('current_time')) {
        this.current_time = initObj.current_time
      }
      else {
        this.current_time = 0.0;
      }
      if (initObj.hasOwnProperty('running')) {
        this.running = initObj.running
      }
      else {
        this.running = false;
      }
      if (initObj.hasOwnProperty('paused')) {
        this.paused = initObj.paused
      }
      else {
        this.paused = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CurrentResponse
    // Serialize message field [performance]
    bufferOffset = _serializer.string(obj.performance, buffer, bufferOffset);
    // Serialize message field [current_time]
    bufferOffset = _serializer.float32(obj.current_time, buffer, bufferOffset);
    // Serialize message field [running]
    bufferOffset = _serializer.bool(obj.running, buffer, bufferOffset);
    // Serialize message field [paused]
    bufferOffset = _serializer.bool(obj.paused, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CurrentResponse
    let len;
    let data = new CurrentResponse(null);
    // Deserialize message field [performance]
    data.performance = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_time]
    data.current_time = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [running]
    data.running = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [paused]
    data.paused = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.performance.length;
    return length + 10;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/CurrentResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e6dbf41146382c54f075c7d12a569dda';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string performance
    float32 current_time
    bool running
    bool paused
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CurrentResponse(null);
    if (msg.performance !== undefined) {
      resolved.performance = msg.performance;
    }
    else {
      resolved.performance = ''
    }

    if (msg.current_time !== undefined) {
      resolved.current_time = msg.current_time;
    }
    else {
      resolved.current_time = 0.0
    }

    if (msg.running !== undefined) {
      resolved.running = msg.running;
    }
    else {
      resolved.running = false
    }

    if (msg.paused !== undefined) {
      resolved.paused = msg.paused;
    }
    else {
      resolved.paused = false
    }

    return resolved;
    }
};

module.exports = {
  Request: CurrentRequest,
  Response: CurrentResponse,
  md5sum() { return 'e6dbf41146382c54f075c7d12a569dda'; },
  datatype() { return 'hr_msgs/Current'; }
};
