// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Assign {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.fsdk_id = null;
      this.uid = null;
      this.first_name = null;
      this.last_name = null;
      this.formal_name = null;
      this.is_female = null;
    }
    else {
      if (initObj.hasOwnProperty('fsdk_id')) {
        this.fsdk_id = initObj.fsdk_id
      }
      else {
        this.fsdk_id = 0;
      }
      if (initObj.hasOwnProperty('uid')) {
        this.uid = initObj.uid
      }
      else {
        this.uid = 0;
      }
      if (initObj.hasOwnProperty('first_name')) {
        this.first_name = initObj.first_name
      }
      else {
        this.first_name = '';
      }
      if (initObj.hasOwnProperty('last_name')) {
        this.last_name = initObj.last_name
      }
      else {
        this.last_name = '';
      }
      if (initObj.hasOwnProperty('formal_name')) {
        this.formal_name = initObj.formal_name
      }
      else {
        this.formal_name = '';
      }
      if (initObj.hasOwnProperty('is_female')) {
        this.is_female = initObj.is_female
      }
      else {
        this.is_female = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Assign
    // Serialize message field [fsdk_id]
    bufferOffset = _serializer.uint64(obj.fsdk_id, buffer, bufferOffset);
    // Serialize message field [uid]
    bufferOffset = _serializer.uint64(obj.uid, buffer, bufferOffset);
    // Serialize message field [first_name]
    bufferOffset = _serializer.string(obj.first_name, buffer, bufferOffset);
    // Serialize message field [last_name]
    bufferOffset = _serializer.string(obj.last_name, buffer, bufferOffset);
    // Serialize message field [formal_name]
    bufferOffset = _serializer.string(obj.formal_name, buffer, bufferOffset);
    // Serialize message field [is_female]
    bufferOffset = _serializer.bool(obj.is_female, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Assign
    let len;
    let data = new Assign(null);
    // Deserialize message field [fsdk_id]
    data.fsdk_id = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [uid]
    data.uid = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [first_name]
    data.first_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [last_name]
    data.last_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [formal_name]
    data.formal_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [is_female]
    data.is_female = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.first_name.length;
    length += object.last_name.length;
    length += object.formal_name.length;
    return length + 29;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Assign';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2ccd43b198d106cfe778221cbc12f75b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint64 fsdk_id
    uint64 uid
    string first_name
    string last_name
    string formal_name
    bool is_female
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Assign(null);
    if (msg.fsdk_id !== undefined) {
      resolved.fsdk_id = msg.fsdk_id;
    }
    else {
      resolved.fsdk_id = 0
    }

    if (msg.uid !== undefined) {
      resolved.uid = msg.uid;
    }
    else {
      resolved.uid = 0
    }

    if (msg.first_name !== undefined) {
      resolved.first_name = msg.first_name;
    }
    else {
      resolved.first_name = ''
    }

    if (msg.last_name !== undefined) {
      resolved.last_name = msg.last_name;
    }
    else {
      resolved.last_name = ''
    }

    if (msg.formal_name !== undefined) {
      resolved.formal_name = msg.formal_name;
    }
    else {
      resolved.formal_name = ''
    }

    if (msg.is_female !== undefined) {
      resolved.is_female = msg.is_female;
    }
    else {
      resolved.is_female = false
    }

    return resolved;
    }
};

module.exports = Assign;
