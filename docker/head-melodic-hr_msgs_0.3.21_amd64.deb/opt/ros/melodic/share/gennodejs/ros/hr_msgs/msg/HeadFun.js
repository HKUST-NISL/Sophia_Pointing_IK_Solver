// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class HeadFun {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.headRotation = null;
      this.neckDirection = null;
      this.mouth = null;
      this.eyeClosedLeft = null;
      this.eyeClosedRight = null;
      this.eyeHDirLeft = null;
      this.eyeHDirRight = null;
    }
    else {
      if (initObj.hasOwnProperty('headRotation')) {
        this.headRotation = initObj.headRotation
      }
      else {
        this.headRotation = new geometry_msgs.msg.Quaternion();
      }
      if (initObj.hasOwnProperty('neckDirection')) {
        this.neckDirection = initObj.neckDirection
      }
      else {
        this.neckDirection = new geometry_msgs.msg.Vector3();
      }
      if (initObj.hasOwnProperty('mouth')) {
        this.mouth = initObj.mouth
      }
      else {
        this.mouth = 0.0;
      }
      if (initObj.hasOwnProperty('eyeClosedLeft')) {
        this.eyeClosedLeft = initObj.eyeClosedLeft
      }
      else {
        this.eyeClosedLeft = 0.0;
      }
      if (initObj.hasOwnProperty('eyeClosedRight')) {
        this.eyeClosedRight = initObj.eyeClosedRight
      }
      else {
        this.eyeClosedRight = 0.0;
      }
      if (initObj.hasOwnProperty('eyeHDirLeft')) {
        this.eyeHDirLeft = initObj.eyeHDirLeft
      }
      else {
        this.eyeHDirLeft = 0.0;
      }
      if (initObj.hasOwnProperty('eyeHDirRight')) {
        this.eyeHDirRight = initObj.eyeHDirRight
      }
      else {
        this.eyeHDirRight = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type HeadFun
    // Serialize message field [headRotation]
    bufferOffset = geometry_msgs.msg.Quaternion.serialize(obj.headRotation, buffer, bufferOffset);
    // Serialize message field [neckDirection]
    bufferOffset = geometry_msgs.msg.Vector3.serialize(obj.neckDirection, buffer, bufferOffset);
    // Serialize message field [mouth]
    bufferOffset = _serializer.float64(obj.mouth, buffer, bufferOffset);
    // Serialize message field [eyeClosedLeft]
    bufferOffset = _serializer.float64(obj.eyeClosedLeft, buffer, bufferOffset);
    // Serialize message field [eyeClosedRight]
    bufferOffset = _serializer.float64(obj.eyeClosedRight, buffer, bufferOffset);
    // Serialize message field [eyeHDirLeft]
    bufferOffset = _serializer.float64(obj.eyeHDirLeft, buffer, bufferOffset);
    // Serialize message field [eyeHDirRight]
    bufferOffset = _serializer.float64(obj.eyeHDirRight, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type HeadFun
    let len;
    let data = new HeadFun(null);
    // Deserialize message field [headRotation]
    data.headRotation = geometry_msgs.msg.Quaternion.deserialize(buffer, bufferOffset);
    // Deserialize message field [neckDirection]
    data.neckDirection = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset);
    // Deserialize message field [mouth]
    data.mouth = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eyeClosedLeft]
    data.eyeClosedLeft = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eyeClosedRight]
    data.eyeClosedRight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eyeHDirLeft]
    data.eyeHDirLeft = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eyeHDirRight]
    data.eyeHDirRight = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 96;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/HeadFun';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6d33c8823e41cb42d4cac0d2540c9079';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Quaternion headRotation
    geometry_msgs/Vector3    neckDirection
    
    float64 mouth          # 0: closed mouth -> 1: open mouth
    float64 eyeClosedLeft  # 0: open eye -> 1: closed eye
    float64 eyeClosedRight # 0: open eye -> 1: closed eye
    float64 eyeHDirLeft    # horizontal direction (-1 to 1)
    float64 eyeHDirRight   # horizontal direction (-1 to 1)
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new HeadFun(null);
    if (msg.headRotation !== undefined) {
      resolved.headRotation = geometry_msgs.msg.Quaternion.Resolve(msg.headRotation)
    }
    else {
      resolved.headRotation = new geometry_msgs.msg.Quaternion()
    }

    if (msg.neckDirection !== undefined) {
      resolved.neckDirection = geometry_msgs.msg.Vector3.Resolve(msg.neckDirection)
    }
    else {
      resolved.neckDirection = new geometry_msgs.msg.Vector3()
    }

    if (msg.mouth !== undefined) {
      resolved.mouth = msg.mouth;
    }
    else {
      resolved.mouth = 0.0
    }

    if (msg.eyeClosedLeft !== undefined) {
      resolved.eyeClosedLeft = msg.eyeClosedLeft;
    }
    else {
      resolved.eyeClosedLeft = 0.0
    }

    if (msg.eyeClosedRight !== undefined) {
      resolved.eyeClosedRight = msg.eyeClosedRight;
    }
    else {
      resolved.eyeClosedRight = 0.0
    }

    if (msg.eyeHDirLeft !== undefined) {
      resolved.eyeHDirLeft = msg.eyeHDirLeft;
    }
    else {
      resolved.eyeHDirLeft = 0.0
    }

    if (msg.eyeHDirRight !== undefined) {
      resolved.eyeHDirRight = msg.eyeHDirRight;
    }
    else {
      resolved.eyeHDirRight = 0.0
    }

    return resolved;
    }
};

module.exports = HeadFun;
