// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetAnimationLengthRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.animation = null;
    }
    else {
      if (initObj.hasOwnProperty('animation')) {
        this.animation = initObj.animation
      }
      else {
        this.animation = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAnimationLengthRequest
    // Serialize message field [animation]
    bufferOffset = _serializer.string(obj.animation, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAnimationLengthRequest
    let len;
    let data = new GetAnimationLengthRequest(null);
    // Deserialize message field [animation]
    data.animation = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.animation.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/GetAnimationLengthRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'db89f9833114d6b9e2251b31ca30722a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string animation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAnimationLengthRequest(null);
    if (msg.animation !== undefined) {
      resolved.animation = msg.animation;
    }
    else {
      resolved.animation = ''
    }

    return resolved;
    }
};

class GetAnimationLengthResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.length = null;
    }
    else {
      if (initObj.hasOwnProperty('length')) {
        this.length = initObj.length
      }
      else {
        this.length = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAnimationLengthResponse
    // Serialize message field [length]
    bufferOffset = _serializer.float32(obj.length, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAnimationLengthResponse
    let len;
    let data = new GetAnimationLengthResponse(null);
    // Deserialize message field [length]
    data.length = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/GetAnimationLengthResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '30516591bd33c945cbc4d8d225f8022b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 length
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAnimationLengthResponse(null);
    if (msg.length !== undefined) {
      resolved.length = msg.length;
    }
    else {
      resolved.length = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: GetAnimationLengthRequest,
  Response: GetAnimationLengthResponse,
  md5sum() { return 'fe4f383317a23749366d3cd09901e844'; },
  datatype() { return 'hr_msgs/GetAnimationLength'; }
};
