// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class pau {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.m_headRotation = null;
      this.m_headTranslation = null;
      this.m_neckRotation = null;
      this.m_eyeGazeLeftPitch = null;
      this.m_eyeGazeLeftYaw = null;
      this.m_eyeGazeRightPitch = null;
      this.m_eyeGazeRightYaw = null;
      this.m_coeffs = null;
      this.m_shapekeys = null;
      this.m_angles = null;
      this.m_joints = null;
    }
    else {
      if (initObj.hasOwnProperty('m_headRotation')) {
        this.m_headRotation = initObj.m_headRotation
      }
      else {
        this.m_headRotation = new geometry_msgs.msg.Quaternion();
      }
      if (initObj.hasOwnProperty('m_headTranslation')) {
        this.m_headTranslation = initObj.m_headTranslation
      }
      else {
        this.m_headTranslation = new geometry_msgs.msg.Vector3();
      }
      if (initObj.hasOwnProperty('m_neckRotation')) {
        this.m_neckRotation = initObj.m_neckRotation
      }
      else {
        this.m_neckRotation = new geometry_msgs.msg.Quaternion();
      }
      if (initObj.hasOwnProperty('m_eyeGazeLeftPitch')) {
        this.m_eyeGazeLeftPitch = initObj.m_eyeGazeLeftPitch
      }
      else {
        this.m_eyeGazeLeftPitch = 0.0;
      }
      if (initObj.hasOwnProperty('m_eyeGazeLeftYaw')) {
        this.m_eyeGazeLeftYaw = initObj.m_eyeGazeLeftYaw
      }
      else {
        this.m_eyeGazeLeftYaw = 0.0;
      }
      if (initObj.hasOwnProperty('m_eyeGazeRightPitch')) {
        this.m_eyeGazeRightPitch = initObj.m_eyeGazeRightPitch
      }
      else {
        this.m_eyeGazeRightPitch = 0.0;
      }
      if (initObj.hasOwnProperty('m_eyeGazeRightYaw')) {
        this.m_eyeGazeRightYaw = initObj.m_eyeGazeRightYaw
      }
      else {
        this.m_eyeGazeRightYaw = 0.0;
      }
      if (initObj.hasOwnProperty('m_coeffs')) {
        this.m_coeffs = initObj.m_coeffs
      }
      else {
        this.m_coeffs = [];
      }
      if (initObj.hasOwnProperty('m_shapekeys')) {
        this.m_shapekeys = initObj.m_shapekeys
      }
      else {
        this.m_shapekeys = [];
      }
      if (initObj.hasOwnProperty('m_angles')) {
        this.m_angles = initObj.m_angles
      }
      else {
        this.m_angles = [];
      }
      if (initObj.hasOwnProperty('m_joints')) {
        this.m_joints = initObj.m_joints
      }
      else {
        this.m_joints = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type pau
    // Serialize message field [m_headRotation]
    bufferOffset = geometry_msgs.msg.Quaternion.serialize(obj.m_headRotation, buffer, bufferOffset);
    // Serialize message field [m_headTranslation]
    bufferOffset = geometry_msgs.msg.Vector3.serialize(obj.m_headTranslation, buffer, bufferOffset);
    // Serialize message field [m_neckRotation]
    bufferOffset = geometry_msgs.msg.Quaternion.serialize(obj.m_neckRotation, buffer, bufferOffset);
    // Serialize message field [m_eyeGazeLeftPitch]
    bufferOffset = _serializer.float32(obj.m_eyeGazeLeftPitch, buffer, bufferOffset);
    // Serialize message field [m_eyeGazeLeftYaw]
    bufferOffset = _serializer.float32(obj.m_eyeGazeLeftYaw, buffer, bufferOffset);
    // Serialize message field [m_eyeGazeRightPitch]
    bufferOffset = _serializer.float32(obj.m_eyeGazeRightPitch, buffer, bufferOffset);
    // Serialize message field [m_eyeGazeRightYaw]
    bufferOffset = _serializer.float32(obj.m_eyeGazeRightYaw, buffer, bufferOffset);
    // Serialize message field [m_coeffs]
    bufferOffset = _arraySerializer.float32(obj.m_coeffs, buffer, bufferOffset, null);
    // Serialize message field [m_shapekeys]
    bufferOffset = _arraySerializer.string(obj.m_shapekeys, buffer, bufferOffset, null);
    // Serialize message field [m_angles]
    bufferOffset = _arraySerializer.float32(obj.m_angles, buffer, bufferOffset, null);
    // Serialize message field [m_joints]
    bufferOffset = _arraySerializer.string(obj.m_joints, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type pau
    let len;
    let data = new pau(null);
    // Deserialize message field [m_headRotation]
    data.m_headRotation = geometry_msgs.msg.Quaternion.deserialize(buffer, bufferOffset);
    // Deserialize message field [m_headTranslation]
    data.m_headTranslation = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset);
    // Deserialize message field [m_neckRotation]
    data.m_neckRotation = geometry_msgs.msg.Quaternion.deserialize(buffer, bufferOffset);
    // Deserialize message field [m_eyeGazeLeftPitch]
    data.m_eyeGazeLeftPitch = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m_eyeGazeLeftYaw]
    data.m_eyeGazeLeftYaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m_eyeGazeRightPitch]
    data.m_eyeGazeRightPitch = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m_eyeGazeRightYaw]
    data.m_eyeGazeRightYaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [m_coeffs]
    data.m_coeffs = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [m_shapekeys]
    data.m_shapekeys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [m_angles]
    data.m_angles = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [m_joints]
    data.m_joints = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.m_coeffs.length;
    object.m_shapekeys.forEach((val) => {
      length += 4 + val.length;
    });
    length += 4 * object.m_angles.length;
    object.m_joints.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 120;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/pau';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9906773dfb147e4e488f797b82568385';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Quaternion m_headRotation
    geometry_msgs/Vector3    m_headTranslation
    geometry_msgs/Quaternion m_neckRotation
    
    float32 m_eyeGazeLeftPitch
    float32 m_eyeGazeLeftYaw
    float32 m_eyeGazeRightPitch
    float32 m_eyeGazeRightYaw
    
    #An array of blendshape coefficients.
    #They describe an expression of a virtual face.
    float32[] m_coeffs
    # Then setting shapekey values, names must be passed
    string[] m_shapekeys
    
    #An array of arm/hand joint angles.
    float32[] m_angles
    string[] m_joints
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new pau(null);
    if (msg.m_headRotation !== undefined) {
      resolved.m_headRotation = geometry_msgs.msg.Quaternion.Resolve(msg.m_headRotation)
    }
    else {
      resolved.m_headRotation = new geometry_msgs.msg.Quaternion()
    }

    if (msg.m_headTranslation !== undefined) {
      resolved.m_headTranslation = geometry_msgs.msg.Vector3.Resolve(msg.m_headTranslation)
    }
    else {
      resolved.m_headTranslation = new geometry_msgs.msg.Vector3()
    }

    if (msg.m_neckRotation !== undefined) {
      resolved.m_neckRotation = geometry_msgs.msg.Quaternion.Resolve(msg.m_neckRotation)
    }
    else {
      resolved.m_neckRotation = new geometry_msgs.msg.Quaternion()
    }

    if (msg.m_eyeGazeLeftPitch !== undefined) {
      resolved.m_eyeGazeLeftPitch = msg.m_eyeGazeLeftPitch;
    }
    else {
      resolved.m_eyeGazeLeftPitch = 0.0
    }

    if (msg.m_eyeGazeLeftYaw !== undefined) {
      resolved.m_eyeGazeLeftYaw = msg.m_eyeGazeLeftYaw;
    }
    else {
      resolved.m_eyeGazeLeftYaw = 0.0
    }

    if (msg.m_eyeGazeRightPitch !== undefined) {
      resolved.m_eyeGazeRightPitch = msg.m_eyeGazeRightPitch;
    }
    else {
      resolved.m_eyeGazeRightPitch = 0.0
    }

    if (msg.m_eyeGazeRightYaw !== undefined) {
      resolved.m_eyeGazeRightYaw = msg.m_eyeGazeRightYaw;
    }
    else {
      resolved.m_eyeGazeRightYaw = 0.0
    }

    if (msg.m_coeffs !== undefined) {
      resolved.m_coeffs = msg.m_coeffs;
    }
    else {
      resolved.m_coeffs = []
    }

    if (msg.m_shapekeys !== undefined) {
      resolved.m_shapekeys = msg.m_shapekeys;
    }
    else {
      resolved.m_shapekeys = []
    }

    if (msg.m_angles !== undefined) {
      resolved.m_angles = msg.m_angles;
    }
    else {
      resolved.m_angles = []
    }

    if (msg.m_joints !== undefined) {
      resolved.m_joints = msg.m_joints;
    }
    else {
      resolved.m_joints = []
    }

    return resolved;
    }
};

module.exports = pau;
