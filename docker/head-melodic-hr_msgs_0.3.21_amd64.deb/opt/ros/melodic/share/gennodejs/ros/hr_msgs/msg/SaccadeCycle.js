// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SaccadeCycle {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mean = null;
      this.variation = null;
      this.paint_scale = null;
      this.eye_size = null;
      this.eye_distance = null;
      this.mouth_width = null;
      this.mouth_height = null;
      this.weight_eyes = null;
      this.weight_mouth = null;
    }
    else {
      if (initObj.hasOwnProperty('mean')) {
        this.mean = initObj.mean
      }
      else {
        this.mean = 0.0;
      }
      if (initObj.hasOwnProperty('variation')) {
        this.variation = initObj.variation
      }
      else {
        this.variation = 0.0;
      }
      if (initObj.hasOwnProperty('paint_scale')) {
        this.paint_scale = initObj.paint_scale
      }
      else {
        this.paint_scale = 0.0;
      }
      if (initObj.hasOwnProperty('eye_size')) {
        this.eye_size = initObj.eye_size
      }
      else {
        this.eye_size = 0.0;
      }
      if (initObj.hasOwnProperty('eye_distance')) {
        this.eye_distance = initObj.eye_distance
      }
      else {
        this.eye_distance = 0.0;
      }
      if (initObj.hasOwnProperty('mouth_width')) {
        this.mouth_width = initObj.mouth_width
      }
      else {
        this.mouth_width = 0.0;
      }
      if (initObj.hasOwnProperty('mouth_height')) {
        this.mouth_height = initObj.mouth_height
      }
      else {
        this.mouth_height = 0.0;
      }
      if (initObj.hasOwnProperty('weight_eyes')) {
        this.weight_eyes = initObj.weight_eyes
      }
      else {
        this.weight_eyes = 0.0;
      }
      if (initObj.hasOwnProperty('weight_mouth')) {
        this.weight_mouth = initObj.weight_mouth
      }
      else {
        this.weight_mouth = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaccadeCycle
    // Serialize message field [mean]
    bufferOffset = _serializer.float32(obj.mean, buffer, bufferOffset);
    // Serialize message field [variation]
    bufferOffset = _serializer.float32(obj.variation, buffer, bufferOffset);
    // Serialize message field [paint_scale]
    bufferOffset = _serializer.float32(obj.paint_scale, buffer, bufferOffset);
    // Serialize message field [eye_size]
    bufferOffset = _serializer.float32(obj.eye_size, buffer, bufferOffset);
    // Serialize message field [eye_distance]
    bufferOffset = _serializer.float32(obj.eye_distance, buffer, bufferOffset);
    // Serialize message field [mouth_width]
    bufferOffset = _serializer.float32(obj.mouth_width, buffer, bufferOffset);
    // Serialize message field [mouth_height]
    bufferOffset = _serializer.float32(obj.mouth_height, buffer, bufferOffset);
    // Serialize message field [weight_eyes]
    bufferOffset = _serializer.float32(obj.weight_eyes, buffer, bufferOffset);
    // Serialize message field [weight_mouth]
    bufferOffset = _serializer.float32(obj.weight_mouth, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaccadeCycle
    let len;
    let data = new SaccadeCycle(null);
    // Deserialize message field [mean]
    data.mean = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [variation]
    data.variation = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [paint_scale]
    data.paint_scale = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [eye_size]
    data.eye_size = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [eye_distance]
    data.eye_distance = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mouth_width]
    data.mouth_width = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mouth_height]
    data.mouth_height = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [weight_eyes]
    data.weight_eyes = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [weight_mouth]
    data.weight_mouth = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/SaccadeCycle';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2ddd4aa1af1ce0e41299d9e0d97ba48f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 mean
    float32 variation
    float32 paint_scale
    float32 eye_size
    float32 eye_distance
    float32 mouth_width
    float32 mouth_height
    float32 weight_eyes
    float32 weight_mouth
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaccadeCycle(null);
    if (msg.mean !== undefined) {
      resolved.mean = msg.mean;
    }
    else {
      resolved.mean = 0.0
    }

    if (msg.variation !== undefined) {
      resolved.variation = msg.variation;
    }
    else {
      resolved.variation = 0.0
    }

    if (msg.paint_scale !== undefined) {
      resolved.paint_scale = msg.paint_scale;
    }
    else {
      resolved.paint_scale = 0.0
    }

    if (msg.eye_size !== undefined) {
      resolved.eye_size = msg.eye_size;
    }
    else {
      resolved.eye_size = 0.0
    }

    if (msg.eye_distance !== undefined) {
      resolved.eye_distance = msg.eye_distance;
    }
    else {
      resolved.eye_distance = 0.0
    }

    if (msg.mouth_width !== undefined) {
      resolved.mouth_width = msg.mouth_width;
    }
    else {
      resolved.mouth_width = 0.0
    }

    if (msg.mouth_height !== undefined) {
      resolved.mouth_height = msg.mouth_height;
    }
    else {
      resolved.mouth_height = 0.0
    }

    if (msg.weight_eyes !== undefined) {
      resolved.weight_eyes = msg.weight_eyes;
    }
    else {
      resolved.weight_eyes = 0.0
    }

    if (msg.weight_mouth !== undefined) {
      resolved.weight_mouth = msg.weight_mouth;
    }
    else {
      resolved.weight_mouth = 0.0
    }

    return resolved;
    }
};

module.exports = SaccadeCycle;
