// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SourceInfo = require('./SourceInfo.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ManyEarsTrackedAudioSource {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.sequence = null;
      this.tracked_sources = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('sequence')) {
        this.sequence = initObj.sequence
      }
      else {
        this.sequence = 0;
      }
      if (initObj.hasOwnProperty('tracked_sources')) {
        this.tracked_sources = initObj.tracked_sources
      }
      else {
        this.tracked_sources = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ManyEarsTrackedAudioSource
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [sequence]
    bufferOffset = _serializer.uint32(obj.sequence, buffer, bufferOffset);
    // Serialize message field [tracked_sources]
    // Serialize the length for message field [tracked_sources]
    bufferOffset = _serializer.uint32(obj.tracked_sources.length, buffer, bufferOffset);
    obj.tracked_sources.forEach((val) => {
      bufferOffset = SourceInfo.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ManyEarsTrackedAudioSource
    let len;
    let data = new ManyEarsTrackedAudioSource(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [sequence]
    data.sequence = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [tracked_sources]
    // Deserialize array length for message field [tracked_sources]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tracked_sources = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tracked_sources[i] = SourceInfo.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.tracked_sources.forEach((val) => {
      length += SourceInfo.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/ManyEarsTrackedAudioSource';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '70dda5189f892ad13dfeabc30e51e615';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    Header header
    
    #id
    uint32 sequence
    
    #Array of tracked sources
    SourceInfo[] tracked_sources
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: hr_msgs/SourceInfo
    #Tracked source information
    uint32 source_id
    geometry_msgs/Point source_pos
    float32 longitude   # In degrees
    float32 latitude    # In degrees 
    float32 source_probability
    float32[] separation_data # Separation data (audio stream)
    float32[] postfiltered_data # Postfiltered data (audio stream)
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ManyEarsTrackedAudioSource(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.sequence !== undefined) {
      resolved.sequence = msg.sequence;
    }
    else {
      resolved.sequence = 0
    }

    if (msg.tracked_sources !== undefined) {
      resolved.tracked_sources = new Array(msg.tracked_sources.length);
      for (let i = 0; i < resolved.tracked_sources.length; ++i) {
        resolved.tracked_sources[i] = SourceInfo.Resolve(msg.tracked_sources[i]);
      }
    }
    else {
      resolved.tracked_sources = []
    }

    return resolved;
    }
};

module.exports = ManyEarsTrackedAudioSource;
