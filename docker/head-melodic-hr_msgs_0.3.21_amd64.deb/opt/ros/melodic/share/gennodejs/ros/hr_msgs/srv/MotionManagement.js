// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class MotionManagementRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.action = null;
      this.motionName = null;
    }
    else {
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = 0;
      }
      if (initObj.hasOwnProperty('motionName')) {
        this.motionName = initObj.motionName
      }
      else {
        this.motionName = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotionManagementRequest
    // Serialize message field [action]
    bufferOffset = _serializer.int32(obj.action, buffer, bufferOffset);
    // Serialize message field [motionName]
    bufferOffset = _serializer.string(obj.motionName, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotionManagementRequest
    let len;
    let data = new MotionManagementRequest(null);
    // Deserialize message field [action]
    data.action = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [motionName]
    data.motionName = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.motionName.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/MotionManagementRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '131233cec8c41411cf7e9127e42a3997';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    int32 activateMotion   = 1
    int32 deactivateMotion = 2
    int32 action
    
    
    string motionName
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotionManagementRequest(null);
    if (msg.action !== undefined) {
      resolved.action = msg.action;
    }
    else {
      resolved.action = 0
    }

    if (msg.motionName !== undefined) {
      resolved.motionName = msg.motionName;
    }
    else {
      resolved.motionName = ''
    }

    return resolved;
    }
};

// Constants for message
MotionManagementRequest.Constants = {
  ACTIVATEMOTION: 1,
  DEACTIVATEMOTION: 2,
}

class MotionManagementResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.errorMessage = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('errorMessage')) {
        this.errorMessage = initObj.errorMessage
      }
      else {
        this.errorMessage = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotionManagementResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [errorMessage]
    bufferOffset = _serializer.string(obj.errorMessage, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotionManagementResponse
    let len;
    let data = new MotionManagementResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [errorMessage]
    data.errorMessage = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.errorMessage.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/MotionManagementResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '28da2c6cf06564caa0fabfcd179905d2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool success
    
    
    string errorMessage
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotionManagementResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.errorMessage !== undefined) {
      resolved.errorMessage = msg.errorMessage;
    }
    else {
      resolved.errorMessage = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: MotionManagementRequest,
  Response: MotionManagementResponse,
  md5sum() { return 'e7e4739d0986faefb840dbb7e98a28e8'; },
  datatype() { return 'hr_msgs/MotionManagement'; }
};
