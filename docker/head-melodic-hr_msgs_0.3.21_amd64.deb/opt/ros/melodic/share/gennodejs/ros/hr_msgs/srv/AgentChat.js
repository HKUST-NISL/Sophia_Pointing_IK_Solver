// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class AgentChatRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.text = null;
      this.lang = null;
      this.session = null;
    }
    else {
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('lang')) {
        this.lang = initObj.lang
      }
      else {
        this.lang = '';
      }
      if (initObj.hasOwnProperty('session')) {
        this.session = initObj.session
      }
      else {
        this.session = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AgentChatRequest
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [lang]
    bufferOffset = _serializer.string(obj.lang, buffer, bufferOffset);
    // Serialize message field [session]
    bufferOffset = _serializer.string(obj.session, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AgentChatRequest
    let len;
    let data = new AgentChatRequest(null);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lang]
    data.lang = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [session]
    data.session = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.text.length;
    length += object.lang.length;
    length += object.session.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/AgentChatRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6fd0c0e346ad2be8623fa7d8a07e6576';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string text
    string lang
    string session
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AgentChatRequest(null);
    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.lang !== undefined) {
      resolved.lang = msg.lang;
    }
    else {
      resolved.lang = ''
    }

    if (msg.session !== undefined) {
      resolved.session = msg.session;
    }
    else {
      resolved.session = ''
    }

    return resolved;
    }
};

class AgentChatResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.state = null;
      this.answer = null;
      this.score = null;
    }
    else {
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('answer')) {
        this.answer = initObj.answer
      }
      else {
        this.answer = '';
      }
      if (initObj.hasOwnProperty('score')) {
        this.score = initObj.score
      }
      else {
        this.score = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AgentChatResponse
    // Serialize message field [state]
    bufferOffset = _serializer.int32(obj.state, buffer, bufferOffset);
    // Serialize message field [answer]
    bufferOffset = _serializer.string(obj.answer, buffer, bufferOffset);
    // Serialize message field [score]
    bufferOffset = _serializer.float64(obj.score, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AgentChatResponse
    let len;
    let data = new AgentChatResponse(null);
    // Deserialize message field [state]
    data.state = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [answer]
    data.answer = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [score]
    data.score = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.answer.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/AgentChatResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '44cddbeb892be5a480c600959701420d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 state
    string answer
    float64 score
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AgentChatResponse(null);
    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.answer !== undefined) {
      resolved.answer = msg.answer;
    }
    else {
      resolved.answer = ''
    }

    if (msg.score !== undefined) {
      resolved.score = msg.score;
    }
    else {
      resolved.score = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: AgentChatRequest,
  Response: AgentChatResponse,
  md5sum() { return '8e125bdc4ee1c1329dc1796b0e98a551'; },
  datatype() { return 'hr_msgs/AgentChat'; }
};
