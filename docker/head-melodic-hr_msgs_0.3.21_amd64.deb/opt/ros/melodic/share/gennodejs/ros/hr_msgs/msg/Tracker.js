// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Object = require('./Object.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Tracker {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.object = null;
      this.initial_points = null;
      this.active_points = null;
      this.quality_results = null;
      this.tracker_name = null;
      this.recognized_name = null;
      this.recognized = null;
      this.before_demotion = null;
      this.validated = null;
      this.google_best_guess = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('object')) {
        this.object = initObj.object
      }
      else {
        this.object = new Object();
      }
      if (initObj.hasOwnProperty('initial_points')) {
        this.initial_points = initObj.initial_points
      }
      else {
        this.initial_points = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('active_points')) {
        this.active_points = initObj.active_points
      }
      else {
        this.active_points = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('quality_results')) {
        this.quality_results = initObj.quality_results
      }
      else {
        this.quality_results = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('tracker_name')) {
        this.tracker_name = initObj.tracker_name
      }
      else {
        this.tracker_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('recognized_name')) {
        this.recognized_name = initObj.recognized_name
      }
      else {
        this.recognized_name = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('recognized')) {
        this.recognized = initObj.recognized
      }
      else {
        this.recognized = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('before_demotion')) {
        this.before_demotion = initObj.before_demotion
      }
      else {
        this.before_demotion = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('validated')) {
        this.validated = initObj.validated
      }
      else {
        this.validated = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('google_best_guess')) {
        this.google_best_guess = initObj.google_best_guess
      }
      else {
        this.google_best_guess = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Tracker
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [object]
    bufferOffset = Object.serialize(obj.object, buffer, bufferOffset);
    // Serialize message field [initial_points]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.initial_points, buffer, bufferOffset);
    // Serialize message field [active_points]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.active_points, buffer, bufferOffset);
    // Serialize message field [quality_results]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.quality_results, buffer, bufferOffset);
    // Serialize message field [tracker_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.tracker_name, buffer, bufferOffset);
    // Serialize message field [recognized_name]
    bufferOffset = std_msgs.msg.String.serialize(obj.recognized_name, buffer, bufferOffset);
    // Serialize message field [recognized]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.recognized, buffer, bufferOffset);
    // Serialize message field [before_demotion]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.before_demotion, buffer, bufferOffset);
    // Serialize message field [validated]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.validated, buffer, bufferOffset);
    // Serialize message field [google_best_guess]
    bufferOffset = std_msgs.msg.String.serialize(obj.google_best_guess, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Tracker
    let len;
    let data = new Tracker(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [object]
    data.object = Object.deserialize(buffer, bufferOffset);
    // Deserialize message field [initial_points]
    data.initial_points = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [active_points]
    data.active_points = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [quality_results]
    data.quality_results = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [tracker_name]
    data.tracker_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [recognized_name]
    data.recognized_name = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [recognized]
    data.recognized = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [before_demotion]
    data.before_demotion = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [validated]
    data.validated = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [google_best_guess]
    data.google_best_guess = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += Object.getMessageSize(object.object);
    length += std_msgs.msg.String.getMessageSize(object.tracker_name);
    length += std_msgs.msg.String.getMessageSize(object.recognized_name);
    length += std_msgs.msg.String.getMessageSize(object.google_best_guess);
    return length + 15;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Tracker';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a6a14d053d2c664581f299a7e8a149db';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    Object object
    std_msgs/Int32 initial_points
    std_msgs/Int32 active_points #Moving avaerage to destroy as it wouldn't make sense just to remove.
    std_msgs/Bool quality_results # Makes sense
    std_msgs/String tracker_name #This is needed.
    std_msgs/String recognized_name #This is assigned when it's known to have a name
    std_msgs/Bool recognized # This is updated after tracker_name is updated from the recognizer function.
    std_msgs/Int32 before_demotion
    std_msgs/Bool validated #To check for merge fucntions.
    std_msgs/String google_best_guess
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: hr_msgs/Object
    Header header
    sensor_msgs/RegionOfInterest object
    std_msgs/Int32 id
    std_msgs/String obj_states
    std_msgs/Float64 obj_accuracy
    Point2DArray feature_point
    geometry_msgs/Pose pose
    std_msgs/String tool_used_for_detection
    ================================================================================
    MSG: sensor_msgs/RegionOfInterest
    # This message is used to specify a region of interest within an image.
    #
    # When used to specify the ROI setting of the camera when the image was
    # taken, the height and width fields should either match the height and
    # width fields for the associated image; or height = width = 0
    # indicates that the full resolution image was captured.
    
    uint32 x_offset  # Leftmost pixel of the ROI
                     # (0 if the ROI includes the left edge of the image)
    uint32 y_offset  # Topmost pixel of the ROI
                     # (0 if the ROI includes the top edge of the image)
    uint32 height    # Height of ROI
    uint32 width     # Width of ROI
    
    # True if a distinct rectified ROI should be calculated from the "raw"
    # ROI in this message. Typically this should be False if the full image
    # is captured (ROI not used), and True if a subwindow is captured (ROI
    # used).
    bool do_rectify
    
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: hr_msgs/Point2DArray
    Point2D[] points
    
    ================================================================================
    MSG: hr_msgs/Point2D
    float64 x
    float64 y
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Tracker(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.object !== undefined) {
      resolved.object = Object.Resolve(msg.object)
    }
    else {
      resolved.object = new Object()
    }

    if (msg.initial_points !== undefined) {
      resolved.initial_points = std_msgs.msg.Int32.Resolve(msg.initial_points)
    }
    else {
      resolved.initial_points = new std_msgs.msg.Int32()
    }

    if (msg.active_points !== undefined) {
      resolved.active_points = std_msgs.msg.Int32.Resolve(msg.active_points)
    }
    else {
      resolved.active_points = new std_msgs.msg.Int32()
    }

    if (msg.quality_results !== undefined) {
      resolved.quality_results = std_msgs.msg.Bool.Resolve(msg.quality_results)
    }
    else {
      resolved.quality_results = new std_msgs.msg.Bool()
    }

    if (msg.tracker_name !== undefined) {
      resolved.tracker_name = std_msgs.msg.String.Resolve(msg.tracker_name)
    }
    else {
      resolved.tracker_name = new std_msgs.msg.String()
    }

    if (msg.recognized_name !== undefined) {
      resolved.recognized_name = std_msgs.msg.String.Resolve(msg.recognized_name)
    }
    else {
      resolved.recognized_name = new std_msgs.msg.String()
    }

    if (msg.recognized !== undefined) {
      resolved.recognized = std_msgs.msg.Bool.Resolve(msg.recognized)
    }
    else {
      resolved.recognized = new std_msgs.msg.Bool()
    }

    if (msg.before_demotion !== undefined) {
      resolved.before_demotion = std_msgs.msg.Int32.Resolve(msg.before_demotion)
    }
    else {
      resolved.before_demotion = new std_msgs.msg.Int32()
    }

    if (msg.validated !== undefined) {
      resolved.validated = std_msgs.msg.Bool.Resolve(msg.validated)
    }
    else {
      resolved.validated = new std_msgs.msg.Bool()
    }

    if (msg.google_best_guess !== undefined) {
      resolved.google_best_guess = std_msgs.msg.String.Resolve(msg.google_best_guess)
    }
    else {
      resolved.google_best_guess = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = Tracker;
