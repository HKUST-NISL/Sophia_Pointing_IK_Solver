// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ChatMessage {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.utterance = null;
      this.lang = null;
      this.confidence = null;
      this.source = null;
      this.audio_path = null;
    }
    else {
      if (initObj.hasOwnProperty('utterance')) {
        this.utterance = initObj.utterance
      }
      else {
        this.utterance = '';
      }
      if (initObj.hasOwnProperty('lang')) {
        this.lang = initObj.lang
      }
      else {
        this.lang = '';
      }
      if (initObj.hasOwnProperty('confidence')) {
        this.confidence = initObj.confidence
      }
      else {
        this.confidence = 0;
      }
      if (initObj.hasOwnProperty('source')) {
        this.source = initObj.source
      }
      else {
        this.source = '';
      }
      if (initObj.hasOwnProperty('audio_path')) {
        this.audio_path = initObj.audio_path
      }
      else {
        this.audio_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChatMessage
    // Serialize message field [utterance]
    bufferOffset = _serializer.string(obj.utterance, buffer, bufferOffset);
    // Serialize message field [lang]
    bufferOffset = _serializer.string(obj.lang, buffer, bufferOffset);
    // Serialize message field [confidence]
    bufferOffset = _serializer.uint8(obj.confidence, buffer, bufferOffset);
    // Serialize message field [source]
    bufferOffset = _serializer.string(obj.source, buffer, bufferOffset);
    // Serialize message field [audio_path]
    bufferOffset = _serializer.string(obj.audio_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChatMessage
    let len;
    let data = new ChatMessage(null);
    // Deserialize message field [utterance]
    data.utterance = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lang]
    data.lang = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [confidence]
    data.confidence = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [source]
    data.source = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [audio_path]
    data.audio_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.utterance.length;
    length += object.lang.length;
    length += object.source.length;
    length += object.audio_path.length;
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/ChatMessage';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6221bbdc0f7e1c09367354f9f1207761';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string utterance
    string lang
    uint8 confidence
    string source
    string audio_path
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChatMessage(null);
    if (msg.utterance !== undefined) {
      resolved.utterance = msg.utterance;
    }
    else {
      resolved.utterance = ''
    }

    if (msg.lang !== undefined) {
      resolved.lang = msg.lang;
    }
    else {
      resolved.lang = ''
    }

    if (msg.confidence !== undefined) {
      resolved.confidence = msg.confidence;
    }
    else {
      resolved.confidence = 0
    }

    if (msg.source !== undefined) {
      resolved.source = msg.source;
    }
    else {
      resolved.source = ''
    }

    if (msg.audio_path !== undefined) {
      resolved.audio_path = msg.audio_path;
    }
    else {
      resolved.audio_path = ''
    }

    return resolved;
    }
};

module.exports = ChatMessage;
