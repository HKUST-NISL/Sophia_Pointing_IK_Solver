// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class PiVisionFace {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.point = null;
      this.attention = null;
      this.emotion_value = null;
      this.emotion_id = null;
      this.temp_id = null;
      this.recognized = null;
      this.recognized_as = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('point')) {
        this.point = initObj.point
      }
      else {
        this.point = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('attention')) {
        this.attention = initObj.attention
      }
      else {
        this.attention = 0.0;
      }
      if (initObj.hasOwnProperty('emotion_value')) {
        this.emotion_value = initObj.emotion_value
      }
      else {
        this.emotion_value = 0;
      }
      if (initObj.hasOwnProperty('emotion_id')) {
        this.emotion_id = initObj.emotion_id
      }
      else {
        this.emotion_id = '';
      }
      if (initObj.hasOwnProperty('temp_id')) {
        this.temp_id = initObj.temp_id
      }
      else {
        this.temp_id = false;
      }
      if (initObj.hasOwnProperty('recognized')) {
        this.recognized = initObj.recognized
      }
      else {
        this.recognized = false;
      }
      if (initObj.hasOwnProperty('recognized_as')) {
        this.recognized_as = initObj.recognized_as
      }
      else {
        this.recognized_as = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PiVisionFace
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [point]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.point, buffer, bufferOffset);
    // Serialize message field [attention]
    bufferOffset = _serializer.float32(obj.attention, buffer, bufferOffset);
    // Serialize message field [emotion_value]
    bufferOffset = _serializer.int32(obj.emotion_value, buffer, bufferOffset);
    // Serialize message field [emotion_id]
    bufferOffset = _serializer.string(obj.emotion_id, buffer, bufferOffset);
    // Serialize message field [temp_id]
    bufferOffset = _serializer.bool(obj.temp_id, buffer, bufferOffset);
    // Serialize message field [recognized]
    bufferOffset = _serializer.bool(obj.recognized, buffer, bufferOffset);
    // Serialize message field [recognized_as]
    bufferOffset = _serializer.string(obj.recognized_as, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PiVisionFace
    let len;
    let data = new PiVisionFace(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [point]
    data.point = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [attention]
    data.attention = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [emotion_value]
    data.emotion_value = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [emotion_id]
    data.emotion_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [temp_id]
    data.temp_id = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [recognized]
    data.recognized = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [recognized_as]
    data.recognized_as = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.emotion_id.length;
    length += object.recognized_as.length;
    return length + 50;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/PiVisionFace';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '68b66bc70d3e09dd4a9c8e50d3abf589';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Face in 3D space
    int32 id
    string name
    geometry_msgs/Point point
    float32 attention
    # Emotion
    int32 emotion_value
    string emotion_id
    #Temporary
    bool temp_id
    bool recognized
    string recognized_as
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PiVisionFace(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.point !== undefined) {
      resolved.point = geometry_msgs.msg.Point.Resolve(msg.point)
    }
    else {
      resolved.point = new geometry_msgs.msg.Point()
    }

    if (msg.attention !== undefined) {
      resolved.attention = msg.attention;
    }
    else {
      resolved.attention = 0.0
    }

    if (msg.emotion_value !== undefined) {
      resolved.emotion_value = msg.emotion_value;
    }
    else {
      resolved.emotion_value = 0
    }

    if (msg.emotion_id !== undefined) {
      resolved.emotion_id = msg.emotion_id;
    }
    else {
      resolved.emotion_id = ''
    }

    if (msg.temp_id !== undefined) {
      resolved.temp_id = msg.temp_id;
    }
    else {
      resolved.temp_id = false
    }

    if (msg.recognized !== undefined) {
      resolved.recognized = msg.recognized;
    }
    else {
      resolved.recognized = false
    }

    if (msg.recognized_as !== undefined) {
      resolved.recognized_as = msg.recognized_as;
    }
    else {
      resolved.recognized_as = ''
    }

    return resolved;
    }
};

module.exports = PiVisionFace;
