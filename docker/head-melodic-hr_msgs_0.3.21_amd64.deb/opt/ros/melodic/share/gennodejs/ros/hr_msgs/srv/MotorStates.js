// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class MotorStatesRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorStatesRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorStatesRequest
    let len;
    let data = new MotorStatesRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/MotorStatesRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorStatesRequest(null);
    return resolved;
    }
};

class MotorStatesResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.motors = null;
      this.angles = null;
      this.loads = null;
      this.voltages = null;
      this.temperatures = null;
      this.errors = null;
    }
    else {
      if (initObj.hasOwnProperty('motors')) {
        this.motors = initObj.motors
      }
      else {
        this.motors = [];
      }
      if (initObj.hasOwnProperty('angles')) {
        this.angles = initObj.angles
      }
      else {
        this.angles = [];
      }
      if (initObj.hasOwnProperty('loads')) {
        this.loads = initObj.loads
      }
      else {
        this.loads = [];
      }
      if (initObj.hasOwnProperty('voltages')) {
        this.voltages = initObj.voltages
      }
      else {
        this.voltages = [];
      }
      if (initObj.hasOwnProperty('temperatures')) {
        this.temperatures = initObj.temperatures
      }
      else {
        this.temperatures = [];
      }
      if (initObj.hasOwnProperty('errors')) {
        this.errors = initObj.errors
      }
      else {
        this.errors = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorStatesResponse
    // Serialize message field [motors]
    bufferOffset = _arraySerializer.string(obj.motors, buffer, bufferOffset, null);
    // Serialize message field [angles]
    bufferOffset = _arraySerializer.float32(obj.angles, buffer, bufferOffset, null);
    // Serialize message field [loads]
    bufferOffset = _arraySerializer.float64(obj.loads, buffer, bufferOffset, null);
    // Serialize message field [voltages]
    bufferOffset = _arraySerializer.float64(obj.voltages, buffer, bufferOffset, null);
    // Serialize message field [temperatures]
    bufferOffset = _arraySerializer.int32(obj.temperatures, buffer, bufferOffset, null);
    // Serialize message field [errors]
    bufferOffset = _arraySerializer.int32(obj.errors, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorStatesResponse
    let len;
    let data = new MotorStatesResponse(null);
    // Deserialize message field [motors]
    data.motors = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [angles]
    data.angles = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [loads]
    data.loads = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [voltages]
    data.voltages = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [temperatures]
    data.temperatures = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [errors]
    data.errors = _arrayDeserializer.int32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.motors.forEach((val) => {
      length += 4 + val.length;
    });
    length += 4 * object.angles.length;
    length += 8 * object.loads.length;
    length += 8 * object.voltages.length;
    length += 4 * object.temperatures.length;
    length += 4 * object.errors.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/MotorStatesResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ad19929c515b966db2121726f2acce8b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] motors
    float32[] angles
    float64[] loads
    float64[] voltages
    int32[] temperatures
    int32[] errors
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorStatesResponse(null);
    if (msg.motors !== undefined) {
      resolved.motors = msg.motors;
    }
    else {
      resolved.motors = []
    }

    if (msg.angles !== undefined) {
      resolved.angles = msg.angles;
    }
    else {
      resolved.angles = []
    }

    if (msg.loads !== undefined) {
      resolved.loads = msg.loads;
    }
    else {
      resolved.loads = []
    }

    if (msg.voltages !== undefined) {
      resolved.voltages = msg.voltages;
    }
    else {
      resolved.voltages = []
    }

    if (msg.temperatures !== undefined) {
      resolved.temperatures = msg.temperatures;
    }
    else {
      resolved.temperatures = []
    }

    if (msg.errors !== undefined) {
      resolved.errors = msg.errors;
    }
    else {
      resolved.errors = []
    }

    return resolved;
    }
};

module.exports = {
  Request: MotorStatesRequest,
  Response: MotorStatesResponse,
  md5sum() { return 'ad19929c515b966db2121726f2acce8b'; },
  datatype() { return 'hr_msgs/MotorStates'; }
};
